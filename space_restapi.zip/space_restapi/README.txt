********************************************************
All procedures below are based on Windows environment
********************************************************

1) Installation

$ virtualenv venv
$ venv\Scripts\activate
(venv) $ pip install -r requirements.txt


2) Running

(venv) $ python api.py


3) API

  3.1) POST /api/users

	Register a new user.
	The body must contain a JSON object that defines username and password fields, all other fields are optional.
	On success a status code 201 is returned. The body of the response contains a JSON object with the newly added username. A Location header contains the URI of the new user.
	On failure status code 400 (bad request) is returned.
	Example:
	    	Command:
			$ curl -i -X POST -H "Content-Type: application/json" -d "{"""username""":"""weiwang""","""password""":"""abcde""", """email""":"""abc@tb.com""","""lastname""":"""wei""","""firstname""":"""wang"""}" http://127.0.0.1:5000/api/users
             	Return:
			HTTP/1.0 201 CREATED
			Content-Type: application/json
			Content-Length: 27
			Location: http://127.0.0.1:5000/api/users/1
			Server: Werkzeug/0.9.4 Python/2.7.5
			Date: Fri, 11 Apr 2014 08:36:29 GMT
			{
			  "username": "weiwang"
			}

  3.2) GET /api/users/<int:id>

	Retrieve certain user profile. User authentication is required.
	On success a status code 200 is returned. The body of the response contains a JSON object with the user profile. 
	On failure status code 401 is returned for authentication failure. 403 is returned for unauthorized access for other user. 404 is returned for non-existing user profile.
	Example:
		Command:
			$ curl -u weiwang:abcde -i -X GET http://127.0.0.1:5000/api/users/1
		Return:
			HTTP/1.0 200 OK
			Content-Type: application/json
			Content-Length: 143
			Server: Werkzeug/0.9.4 Python/2.7.5
			Date: Fri, 11 Apr 2014 09:06:26 GMT
			{
			  "aboutme": "software engineer",
			  "email": "abc@tb.com",
			  "firstname": "wang",
			  "lastname": "wei",
			  "phonenumber": "510-402-7792",
			  "username": "weiwang"
			}

  3.3) PUT /api/users/<int:id>
	Update certain user profile. User authentication is required.
	The body must contain a JSON object has the updated fields.
	On success a status code 200 is returned. The body of the response contains a JSON object { "Updated": true }
	On failure status code 401 is returned for authentication failure. 403 is returned for unauthorized access for other user. 404 is returned for non-existing user profile, 400 is returned for incorrect fields like confliction in username or invalid email address format.
	Example:
		Command:
			$ curl -u weiwang:abcde -i -X PUT -H "Content-Type: application/json" -d "{"""password""":"""abcde123456789""", """email""":"""newabc@tb.com"""}" http://127.0.0.1:5000/api/users/1
		Return:
			HTTP/1.0 200 OK
			Content-Type: application/json
			Content-Length: 21
			Server: Werkzeug/0.9.4 Python/2.7.5
			Date: Fri, 11 Apr 2014 09:33:38 GMT
			{
			  "Updated": true
			}


  3.4) DELETE /api/users/<int:id>
	Delete certain user profile. User authentication is required.
	On success a status code 200 is returned. The body of the response contains a JSON object { "Deleted": true }
	On failure status code 401 is returned for authentication failure. 403 is returned for unauthorized access for other user. 404 is returned for non-existing user profile.
	Example:
		Command:
			$ curl -u weiwang:abcde123456789 -i -X DELETE http://127.0.0.1:5000/api/users/1
		Return:
			HTTP/1.0 200 OK
			Content-Type: application/json
			Content-Length: 21
			Server: Werkzeug/0.9.4 Python/2.7.5
			Date: Fri, 11 Apr 2014 09:41:22 GMT
			{
			  "Deleted": true
			}
    


