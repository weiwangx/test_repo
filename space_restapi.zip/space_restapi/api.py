#!/usr/bin/env python
import os
from flask import Flask, abort, request, jsonify, g, url_for
from flask.ext.sqlalchemy import SQLAlchemy
from flask.ext.httpauth import HTTPBasicAuth
from passlib.apps import custom_app_context as pwd_context

# initialization
app = Flask(__name__)
app.config['SECRET_KEY'] = 'the quick brown fox jumps over the lazy dog'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite'
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True

# extensions
db = SQLAlchemy(app)
auth = HTTPBasicAuth()


class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), index=True)
    password_hash = db.Column(db.String(64))
    phonenumber = db.Column(db.String(16), index=True)
    email = db.Column(db.String(64), index=True)
    firstname = db.Column(db.String(32), index=True)
    lastname = db.Column(db.String(32), index=True)
    aboutme = db.Column(db.String(1024), index=True)

    def hash_password(self, password):
        self.password_hash = pwd_context.encrypt(password)

    def verify_password(self, password):
        return pwd_context.verify(password, self.password_hash)

@auth.verify_password
def verify_password(username, password):
    user = User.query.filter_by(username = username).first()
    if not user or not user.verify_password(password):
        return False
    g.user = user
    return True

def invalidemail(emailaddress):
    """Checks for a syntactically invalid email address."""
    try:
        emailitems = emailaddress.rsplit('@', 1)
        emailitems.extend(emailitems[1].rsplit('.', 1))
    except IndexError:
        return True

    if [x for x in emailitems if not x.replace(".","").isalnum()] \
            and emailaddress >= 7:
        return True
    else:
        return False

@app.route('/api/users', methods=['POST'])
def new_user():
    username = request.json.get('username')
    password = request.json.get('password')
    phonenumber = request.json.get('phonenumber')
    email = request.json.get('email')
    firstname = request.json.get('firstname')
    lastname = request.json.get('lastname')
    aboutme = request.json.get('aboutme')
    if username is None or password is None:
        abort(400)    # missing arguments
    if User.query.filter_by(username=username).first() is not None:
        abort(400)    # existing user
    if email is not None and invalidemail(email):
        abort(400)
    user = User(username=username,phonenumber=phonenumber,email=email,firstname=firstname,lastname=lastname,aboutme=aboutme)
    user.hash_password(password)
    db.session.add(user)
    db.session.commit()
    return (jsonify({'username': user.username}), 201,
            {'Location': url_for('get_user', id=user.id, _external=True)})

@app.route('/api/users')
@auth.login_required
def get_user_id():
    return (jsonify({'username': g.user.username}), 200,
            {'Location': url_for('get_user', id=g.user.id, _external=True)})

@app.route('/api/users/<int:id>')
@auth.login_required
def get_user(id):
    user = User.query.get(id)
    if not user:
        abort(404)
    if g.user.id != user.id:
        abort(403)
    return jsonify({'username': user.username,  'phonenumber' : user.phonenumber, 'email': user.email, 
                    'firstname': user.firstname, 'lastname': user.lastname, 'aboutme': user.aboutme})

@app.route('/api/users/<int:id>', methods = ['PUT'])
@auth.login_required
def update_user(id):
    user = User.query.get(id)
    if not user:
        abort(404)
    if g.user.id != user.id:
        abort(403)
    username = request.json.get('username')
    password = request.json.get('password')
    phonenumber = request.json.get('phonenumber')
    email = request.json.get('email')
    firstname = request.json.get('firstname')
    lastname = request.json.get('lastname')
    aboutme = request.json.get('aboutme')
    if username is not None: 
        if User.query.filter_by(username=username).first() is not None:
            abort(400)    # existing user
        else:
            user.username=username
    if email is not None:
        if invalidemail(email):
            abort(400)
        else:
            user.email = email
    if password is not None:
        user.hash_password(password)
    if phonenumber is not None:
        user.phonenumber = phonenumber
    if firstname is not None:
        user.firstname = firstname
    if lastname is not None:
        user.lastname = lastname
    if aboutme is not None:
        user.aboutme = aboutme
    db.session.merge(user)
    db.session.commit()
    return jsonify( { 'Updated': True } )


@app.route('/api/users/<int:id>', methods = ['DELETE'])
@auth.login_required
def delete_user(id):
    user = User.query.get(id)
    if not user:
        abort(404)
    if g.user.id != user.id:
        abort(403)
    db.session.delete(user)
    db.session.commit()
    return jsonify( { 'Deleted': True } )

if __name__ == '__main__':
    if not os.path.exists('db.sqlite'):
        db.create_all()
    app.run(debug=True)
